package com.example.demo.Fragment


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.LinearLayout.VERTICAL
import android.widget.TextView
import android.widget.Toast
import com.example.demo.*
import com.example.demo.Adapter.VideoWallAdapter
import com.example.demo.Models.User

import com.example.demo.untill.RecyclerItemClickListenr

class VideoWallFragment : Fragment() {


    var text1:String?= null
    var text2:String?= null

    var text3:String?= null


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_video_wall, container, false)


        var title_text:TextView  = view.findViewById(R.id.title_text)
        var  recycler_list= view.findViewById(R.id.recycler_list)as RecyclerView

        val users = ArrayList<User>()


        users.add(User("Belal Khan", "Ranchi Jharkhand"))
        users.add(User("Ramiz Khan", "Ranchi Jharkhand"))
        users.add(User("Faiz Khan", "Ranchi Jharkhand"))
        users.add(User("Yashar Khan", "Ranchi Jharkhand"))
        text1="<font color=#1d4ca1>140</font> "+

                "<font color=#484848>Video Wall</font>"+
                "<font color=#1d4ca1>Nodia</font>";
        title_text.setText(Html.fromHtml(text1));

        val adapter = VideoWallAdapter()

        recycler_list.addOnItemTouchListener(RecyclerItemClickListenr(requireContext(), recycler_list, object : RecyclerItemClickListenr.OnItemClickListener {

            override fun onItemClick(view: View, position: Int) {

                var intent = Intent(context, TvDeatilsActivity::class.java)
                startActivity(intent)                //do your work here..
            }
            override fun onItemLongClick(view: View?, position: Int) {
                TODO("do nothing")
            }
        }))

        recycler_list.setLayoutManager(LinearLayoutManager(context, VERTICAL,false))


        recycler_list.adapter=adapter

        return view
    }



}
