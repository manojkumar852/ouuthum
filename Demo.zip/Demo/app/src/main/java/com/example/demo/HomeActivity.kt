package com.example.demo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.design.widget.TabLayout
import android.support.v4.view.GravityCompat
import android.support.v4.view.ViewPager
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.widget.Toolbar
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import com.example.demo.Adapter.TabViewPagerAdapter
import kotlinx.android.synthetic.main.nav_header_demo.*

class HomeActivity : AppCompatActivity(),NavigationView.OnNavigationItemSelectedListener {


    var tabLayout: TabLayout? = null
    var viewPager: ViewPager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)


        val boost_ads:Button = findViewById(R.id.boost_ads)
        tabLayout = findViewById<TabLayout>(R.id.tab_layout)
        viewPager = findViewById<ViewPager>(R.id.viewpager)
        val show_toolbar: ImageView = findViewById(R.id.show_toolbar)

        tabLayout!!.addTab(tabLayout!!.newTab().setText("Video Wall"))
        tabLayout!!.addTab(tabLayout!!.newTab().setText("Event"))
        tabLayout!!.tabGravity = TabLayout.GRAVITY_FILL
        val upload_ads:ImageView = findViewById(R.id.upload_ads)



        profile_layout.setOnClickListener {

            intent = Intent(applicationContext, ProfileActivity::class.java)
            startActivity(intent)

        }
        upload_ads.setOnClickListener {

            intent = Intent(applicationContext, UploadAds::class.java)
            startActivity(intent)


        }


        boost_ads.setOnClickListener {
            intent = Intent(applicationContext, UploadAds::class.java)
            startActivity(intent)
        }


        val adapter = TabViewPagerAdapter(this, supportFragmentManager, tabLayout!!.tabCount)
        viewPager!!.adapter = adapter

        viewPager!!.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout))

        tabLayout!!.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                viewPager!!.currentItem = tab.position
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {

            }
            override fun onTabReselected(tab: TabLayout.Tab) {

            }
        })

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
//        val navView: NavigationView = findViewById(R.id.nav_view)
//        navView.setNavigationItemSelectedListener(this)


        show_toolbar.setOnClickListener {
            drawerLayout.openDrawer(Gravity.LEFT)
        }


    }



    override fun onBackPressed() {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }



    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        when (item.itemId) {
            R.id.upload_ads -> {

                intent = Intent(applicationContext, UploadAds::class.java)
                startActivity(intent)

            }
        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

}
