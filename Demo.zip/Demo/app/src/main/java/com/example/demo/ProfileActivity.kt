package com.example.demo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import kotlinx.android.synthetic.main.activity_profile.*

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

//        val pending_ad = findViewById<LinearLayout>(R.id.pending_ads)


        pending_ads. setOnClickListener {

            intent = Intent(applicationContext, PendingAds::class.java)
            startActivity(intent)
        }


        reschdule_ads.setOnClickListener {
            intent = Intent(applicationContext, RescheduleActivity::class.java)
            startActivity(intent)
        }

        runnings_ads.setOnClickListener {
            intent = Intent(applicationContext, RunningAds::class.java)
            startActivity(intent)

        }
    }
}
