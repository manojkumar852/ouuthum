package com.example.demo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.LinearLayout
import com.example.demo.Adapter.ChangeCityAdapter

class ChangeCityActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_city)

      val    change_city_list= findViewById<RecyclerView>(R.id.change_city_list)


        val adapter = ChangeCityAdapter()

        change_city_list.setLayoutManager(LinearLayoutManager(applicationContext, LinearLayout.VERTICAL,false))

        change_city_list.adapter=adapter



    }
}
