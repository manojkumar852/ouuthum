package com.example.demo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class VerifyEmailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify_email)


        var register= findViewById<Button>(R.id.sumbit)


        register.setOnClickListener {

            intent = Intent(applicationContext, HomeActivity::class.java)
            startActivity(intent)
        }
    }
}
