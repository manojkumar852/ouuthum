package com.example.demo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Integer.sum

class MainActivity : AppCompatActivity() {

    var login_button:TextView?=null;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var register= findViewById<Button>(R.id.register)
        var forget_password_text= findViewById<TextView>(R.id.forget_password_text);
        var    login_button= findViewById(R.id.login_button) as Button


        forget_password_text.setOnClickListener {
            intent = Intent(applicationContext, ForgetPasswordActivity::class.java)
            startActivity(intent)
        }
        login_button.setOnClickListener {
            intent = Intent(applicationContext, HomeActivity::class.java)
            startActivity(intent)
        }

        register.setOnClickListener{

            intent = Intent(applicationContext, RegisterActivity::class.java)
            startActivity(intent)
        }

    }
}

