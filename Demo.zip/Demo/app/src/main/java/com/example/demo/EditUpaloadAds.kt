package com.example.demo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout

class EditUpaloadAds : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_upaload_ads)
        val change_city :LinearLayout = findViewById(R.id.change_city)


        change_city.setOnClickListener {
            intent = Intent(applicationContext, ChangeCityActivity::class.java)
            startActivity(intent)
        }
    }
}
