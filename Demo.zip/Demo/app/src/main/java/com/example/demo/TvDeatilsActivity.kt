package com.example.demo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.FloatingActionButton

class TvDeatilsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_tv_deatils)

        val upload_ads:FloatingActionButton = findViewById(R.id.upload_ads)

        upload_ads.setOnClickListener {
            intent = Intent(applicationContext, UploadAds::class.java)
            startActivity(intent)
        }
    }
}
