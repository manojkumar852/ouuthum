package com.example.demo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class UploadAds : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload_ads)

        val upload_ads_button :Button = findViewById(R.id.upload_ads_button)

        upload_ads_button.setOnClickListener {
            intent = Intent(applicationContext, BookDetailsActivity::class.java)
            startActivity(intent)
        }
    }
}
