package com.example.demo

import android.annotation.SuppressLint
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.format.DateFormat
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.example.demo.Fragment.LiveEventFragment
import com.example.demo.Fragment.VideoSitesFragment
import devs.mulham.horizontalcalendar.HorizontalCalendar
import devs.mulham.horizontalcalendar.utils.HorizontalCalendarListener
import java.util.*

class BookingSite : AppCompatActivity() {


    private var horizontalCalendar: HorizontalCalendar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking_site)

    var    video_site= findViewById(R.id.video_site) as TextView
      var   live_event= findViewById(R.id.live_event) as TextView

        val fragment = VideoSitesFragment()
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.booking_site_fragment, fragment)
        transaction.commit()


        video_site.setOnClickListener(object : View.OnClickListener{
            @SuppressLint("ResourceType")
            override fun onClick(v: View?) {

//                live_event.setBackgroundResource(R.drawable.button_bg)
                live_event.setBackgroundResource(R.drawable.button_gray_bg)
                video_site.setBackgroundResource(R.drawable.button_bg)

                video_site.setTextColor(resources.getColor(R.color.white))
                live_event.setTextColor(resources.getColor(R.color.text_color))
                val fragment = VideoSitesFragment()
                val transaction = supportFragmentManager.beginTransaction()
                transaction.replace(R.id.booking_site_fragment, fragment)
                transaction.commit()

                //Your code here
            }})
        live_event.setOnClickListener(object : View.OnClickListener{
            @SuppressLint("ResourceType")
            override fun onClick(v: View?) {

                video_site.setBackgroundResource((R.drawable.button_gray_bg))
                live_event.setBackgroundResource((R.drawable.button_bg))

                live_event.setTextColor(resources.getColor(R.color.white))
                video_site.setTextColor(resources.getColor(R.color.text_color))

                val fragment = LiveEventFragment()
                val transaction = supportFragmentManager.beginTransaction()
                transaction.replace(R.id.booking_site_fragment, fragment)
                transaction.commit()

                //Your code here
            }})

        val startDate = Calendar.getInstance()
        startDate.add(Calendar.MONTH,0)

        /* end after 1 month from now */
        val endDate = Calendar.getInstance()
        endDate.add(Calendar.MONTH, 3)


        horizontalCalendar = HorizontalCalendar.Builder(this, R.id.calendarView)
            .range(startDate, endDate)
            .datesNumberOnScreen(9)
            .configure()
            .formatMiddleText("d")
            .textSize(11f, 20f, 12f)
            .showTopText(true)
            .selectedDateBackground(resources.getDrawable(R.color.blue))
            .showBottomText(true)
            .showTopText(false)

            .textColor(Color.WHITE, Color.WHITE)
            .end()
            .build()

        horizontalCalendar!!.calendarListener = object : HorizontalCalendarListener() {
            override fun onDateSelected(date: Calendar, position: Int) {
                Toast.makeText(applicationContext, DateFormat.format("EEE, MMM d, yyyy", date).toString() + " is selected!", Toast.LENGTH_SHORT).show()
            }

        }






    }
}
