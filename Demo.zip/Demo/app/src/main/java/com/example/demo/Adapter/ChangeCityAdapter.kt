package com.example.demo.Adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import com.example.demo.R
import net.igenius.customcheckbox.CustomCheckBox

class ChangeCityAdapter : RecyclerView.Adapter<ChangeCityAdapter.ViewHolder>() {

    //this method is returning the view for each item in the list
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChangeCityAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.row_change_city_list, parent, false)
        return ViewHolder(v)
    }

    //this method is binding the data on the list
    override fun onBindViewHolder(holder: ChangeCityAdapter.ViewHolder, position: Int) {


        holder.checked.setOnClickListener {
            holder.checkebox.setChecked(true)

        }



    }

    //this method is giving the size of the list
    override fun getItemCount(): Int {
        return 10
    }

    //the class is hodling the list view
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var checked=itemView.findViewById<RelativeLayout>(R.id.checked)
        var  checkebox= itemView.findViewById<CustomCheckBox>(R.id.checked_box)

    }
}