package com.example.demo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class VerifyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify)


        var register= findViewById<Button>(R.id.sumbit)


        register.setOnClickListener {

            intent = Intent(applicationContext, VerifyEmailActivity::class.java)
            startActivity(intent)
        }
    }
}
