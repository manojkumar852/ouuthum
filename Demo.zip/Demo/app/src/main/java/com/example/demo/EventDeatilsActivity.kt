package com.example.demo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.LinearLayout.VERTICAL
import com.example.demo.Adapter.VideoWallAdapter

class EventDeatilsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_deatils)

        var  recycler_list= findViewById(R.id.video_list_recyler)as RecyclerView


        var adpater = VideoWallAdapter()

        recycler_list.setNestedScrollingEnabled(false)

        recycler_list.setLayoutManager(LinearLayoutManager(applicationContext,VERTICAL,false))


        recycler_list.adapter= adpater


    }
}
