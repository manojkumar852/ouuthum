package com.example.demo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class ShowBookDeatails : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_book_deatails)
    }
}
