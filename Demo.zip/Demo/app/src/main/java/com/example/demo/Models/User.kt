package com.example.demo.Models

data class User(val name: String, val address: String)