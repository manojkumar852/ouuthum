package com.example.demo.Fragment


import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.example.demo.Adapter.EventAdapter
import com.example.demo.EventDeatilsActivity

import com.example.demo.R
import com.example.demo.untill.RecyclerItemClickListenr

class EventFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view   = inflater.inflate(R.layout.fragment_event, container, false)

        val event_recycler= view.findViewById<RecyclerView>(R.id.event_recycler)



        event_recycler.addOnItemTouchListener(RecyclerItemClickListenr(requireContext(), event_recycler, object : RecyclerItemClickListenr.OnItemClickListener {

            override fun onItemClick(view: View, position: Int) {

                var intent = Intent(context, EventDeatilsActivity::class.java)
                startActivity(intent)                //do your work here..
            }
            override fun onItemLongClick(view: View?, position: Int) {
                TODO("do nothing")
            }
        }))

        val adapter=EventAdapter()

        event_recycler.setLayoutManager(LinearLayoutManager(context, LinearLayout.VERTICAL,false))

        event_recycler.adapter=adapter

        return  view
    }


}
