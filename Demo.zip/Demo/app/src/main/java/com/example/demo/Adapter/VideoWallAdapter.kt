package com.example.demo.Adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import com.example.demo.Fragment.VideoWallFragment
import com.example.demo.MainActivity
import com.example.demo.Models.User
import com.example.demo.R
import kotlinx.android.synthetic.main.row_video_list.view.*

class VideoWallAdapter : RecyclerView.Adapter<VideoWallAdapter.ViewHolder>() {

    //this method is returning the view for each item in the list
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoWallAdapter.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.row_video_list, parent, false)
        return ViewHolder(v)
    }

    //this method is binding the data on the list
    override fun onBindViewHolder(holder: VideoWallAdapter.ViewHolder, position: Int) {
    }

    //this method is giving the size of the list
    override fun getItemCount(): Int {
        return 10
    }

    //the class is hodling the list view
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}